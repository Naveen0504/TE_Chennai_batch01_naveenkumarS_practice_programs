package com.te.program15a;

public class Details {

	public static String name = "Kishore";

	public int age = 23;
	public int salary = 20000;
}
