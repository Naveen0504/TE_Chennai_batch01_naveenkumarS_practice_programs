package com.te.program9;

public class RecursionTest {

	public static void main(String[] args) {

		System.out.println(Recursion.factorial(5));
	}
}
