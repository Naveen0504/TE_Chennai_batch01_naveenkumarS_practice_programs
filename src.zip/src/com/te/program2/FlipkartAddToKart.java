package com.te.program2;

public class FlipkartAddToKart extends FlipKartTypeCasting {

	public void store() {
		System.out.println("Selected Product added to the Kart");
	}
}
