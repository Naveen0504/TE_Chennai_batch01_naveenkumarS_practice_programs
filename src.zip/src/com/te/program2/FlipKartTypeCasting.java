package com.te.program2;

public class FlipKartTypeCasting {

	public void product() {
		System.out.println("Select the Product");
	}
}
