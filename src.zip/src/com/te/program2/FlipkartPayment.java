package com.te.program2;

public class FlipkartPayment extends FlipkartAddToKart {

	public void payment() {
		System.out.println("Select the Payment Option");
	}
}
