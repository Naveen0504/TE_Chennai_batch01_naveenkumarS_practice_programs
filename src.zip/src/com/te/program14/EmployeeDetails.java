package com.te.program14;

public class EmployeeDetails {

	static String empname = "Kishore";

	int empno = 64;

	public static void salary() {

		System.out.println("Salary By Account");
	}

	public void position() {

		System.out.println("Software Developer");
	}
}
