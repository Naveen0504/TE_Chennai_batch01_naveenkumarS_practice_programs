package com.te.program6;

public class RectangleTest {

	public static void main(String[] args) {

		Rectangle rec = new Rectangle();
		rec.rectangleArea(3.5, 5.0);
		rec.rectanglePerimeter(4.5, 5.0);
	}
}
