package com.te.program6;

public class SquareTest {

	public static void main(String[] args) {

		Square sq = new Square();
		sq.squareArea(2.5);
		sq.squarePerimeter(2.5);
	}
}
