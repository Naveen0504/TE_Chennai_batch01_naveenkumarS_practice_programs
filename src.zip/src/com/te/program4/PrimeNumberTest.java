package com.te.program4;

public class PrimeNumberTest {

	public static void main(String[] args) {

		PrimeNumber ref = new PrimeNumber();
		ref.pgr();
	}
}
