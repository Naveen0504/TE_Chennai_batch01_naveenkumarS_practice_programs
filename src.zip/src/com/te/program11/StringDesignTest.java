package com.te.program11;

public class StringDesignTest {

	public static void main(String[] args) {

		StringDesign ref = new StringDesign();
		ref.test();
	}
}
