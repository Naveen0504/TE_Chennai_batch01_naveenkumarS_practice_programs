package com.te.program10;

public class ColorOsAbstract extends AndroidAbstract {

	@Override
	void ui() {
		System.out.println("Color Os");
	}
}
