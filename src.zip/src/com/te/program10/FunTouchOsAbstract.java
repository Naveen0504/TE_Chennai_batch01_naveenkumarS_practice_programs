package com.te.program10;

public class FunTouchOsAbstract extends AndroidAbstract {

	@Override
	void ui() {
		System.out.println("Fun Touch Os");
	}
}
