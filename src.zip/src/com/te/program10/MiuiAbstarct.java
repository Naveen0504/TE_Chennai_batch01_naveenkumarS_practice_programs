package com.te.program10;

public class MiuiAbstarct extends AndroidAbstract {

	@Override
	void ui() {
		System.out.println("Miui...");
	}
}
