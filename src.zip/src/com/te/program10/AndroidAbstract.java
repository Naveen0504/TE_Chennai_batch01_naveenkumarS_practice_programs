package com.te.program10;

abstract class AndroidAbstract {

	public void calling() {

		System.out.println("Calling....");
	}

	public void messaging() {

		System.out.println("Messaging....");
	}

	abstract void ui();
}
