package com.te.program8;

public class BankAccountTest {

	public static void main(String[] args) {
		WithDraw.withDraw();
		Deposit.deposit(3000);
	}
}
