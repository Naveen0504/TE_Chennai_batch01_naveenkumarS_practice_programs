package com.te.program8;

public class BankAccount {

	static double accBal=10000.0;
	static int amt=5000;
	static int depositamt;
}
