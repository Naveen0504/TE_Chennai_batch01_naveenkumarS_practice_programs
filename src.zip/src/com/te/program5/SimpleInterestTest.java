package com.te.program5;

public class SimpleInterestTest {

	public static void main(String[] args) {

		SimpleInterest ref = new SimpleInterest();
		ref.simple();
	}
}
