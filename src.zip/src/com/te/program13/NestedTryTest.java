package com.te.program13;

public class NestedTryTest {

	public static void main(String[] args) {

		NestedTry ref = new NestedTry();
		ref.test();
	}
}
