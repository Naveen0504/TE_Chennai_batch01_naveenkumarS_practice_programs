package com.te.program16;

public interface DriverInterface {

	public abstract void connect();
}
