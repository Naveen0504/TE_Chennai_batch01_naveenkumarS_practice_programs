package com.te.program16;

public class DriverInterfaceTest extends DriverOracle {

	public static void main(String[] args) {

		DriverInterfaceTest ref = new DriverInterfaceTest();
		ref.connect();
	}
}
