package com.te.program17;

public class InvalidNumberException extends Exception {

}
