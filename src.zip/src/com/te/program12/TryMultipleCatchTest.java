package com.te.program12;

public class TryMultipleCatchTest {

	public static void main(String[] args) {

		TryMultipleCatch ref = new TryMultipleCatch();
		ref.test();
	}
}
