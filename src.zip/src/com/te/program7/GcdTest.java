package com.te.program7;

public class GcdTest {

	public static void main(String[] args) {

		Gcd ref = new Gcd();
		ref.gcd1();
	}
}
